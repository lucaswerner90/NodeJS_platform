const saved_queries={
  catalogo:[],
  users:{},
  proveedor:{},
  generic_info:{}
};

module.exports = saved_queries;
